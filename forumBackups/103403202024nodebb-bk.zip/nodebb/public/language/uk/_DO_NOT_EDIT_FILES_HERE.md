# The files here are not meant to be edited directly

Please see the &rarr; [Internalization README](../README.md).